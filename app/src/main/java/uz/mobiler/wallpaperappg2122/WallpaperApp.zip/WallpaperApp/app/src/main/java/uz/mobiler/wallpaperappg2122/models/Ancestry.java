package uz.mobiler.wallpaperappg2122.models;

public class Ancestry{
    public Type type;
    public Category category;
    public Subcategory subcategory;
}
