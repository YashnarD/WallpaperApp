package uz.mobiler.wallpaperappg2122.models;

import java.util.Date;

public class BusinessWork{
    public String status;
    public Date approved_on;
}
