package uz.mobiler.wallpaperappg2122.models;

import java.util.Date;

public class Interiors{
    public String status;
    public Date approved_on;
}
