package uz.mobiler.wallpaperappg2122.models;

import java.io.Serializable;

public class Links implements Serializable {
    public String self;
    public String html;
    public String download;
    public String download_location;
    public String photos;
    public String likes;
    public String portfolio;
    public String following;
    public String followers;
}
