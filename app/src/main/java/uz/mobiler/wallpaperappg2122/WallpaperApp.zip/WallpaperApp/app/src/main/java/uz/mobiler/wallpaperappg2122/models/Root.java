package uz.mobiler.wallpaperappg2122.models;

import java.util.List;

public class Root{
    public int total;
    public int total_pages;
    public List<Result> results;
}
