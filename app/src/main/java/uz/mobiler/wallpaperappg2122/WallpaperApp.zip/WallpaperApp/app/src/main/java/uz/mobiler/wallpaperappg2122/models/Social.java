package uz.mobiler.wallpaperappg2122.models;

public class Social{
    public String instagram_username;
    public String portfolio_url;
    public String twitter_username;
    public Object paypal_email;
}
