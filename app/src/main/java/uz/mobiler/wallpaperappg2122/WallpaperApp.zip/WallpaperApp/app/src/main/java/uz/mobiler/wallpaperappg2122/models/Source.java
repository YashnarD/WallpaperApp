package uz.mobiler.wallpaperappg2122.models;

public class Source{
    public Ancestry ancestry;
    public String title;
    public String subtitle;
    public String description;
    public String meta_title;
    public String meta_description;
    public CoverPhoto cover_photo;
}
