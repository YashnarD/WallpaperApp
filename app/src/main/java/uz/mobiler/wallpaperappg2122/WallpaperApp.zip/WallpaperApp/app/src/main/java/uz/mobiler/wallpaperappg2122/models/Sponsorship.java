package uz.mobiler.wallpaperappg2122.models;

import java.io.Serializable;
import java.util.List;

public class Sponsorship implements Serializable {
    public List<String> impression_urls;
    public String tagline;
    public String tagline_url;
    public Sponsor sponsor;
}
