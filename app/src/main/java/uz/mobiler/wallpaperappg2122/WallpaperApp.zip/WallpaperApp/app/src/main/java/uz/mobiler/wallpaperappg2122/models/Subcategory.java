package uz.mobiler.wallpaperappg2122.models;

public class Subcategory{
    public String slug;
    public String pretty_slug;
}
