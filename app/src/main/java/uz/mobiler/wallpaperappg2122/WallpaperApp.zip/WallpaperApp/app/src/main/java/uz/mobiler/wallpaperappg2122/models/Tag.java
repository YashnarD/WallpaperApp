package uz.mobiler.wallpaperappg2122.models;

import java.io.Serializable;

public class Tag implements Serializable {
    public String type;
    public String title;
    public Source source;
}
