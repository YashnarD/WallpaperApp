package uz.mobiler.wallpaperappg2122.models;

import java.io.Serializable;

public class TopicSubmissions implements Serializable {
    public BusinessWork businessWork;
    public Wallpapers wallpapers;
    public Interiors interiors;
    public Covid19 covid19;
    public TexturesPatterns texturesPatterns;
}
