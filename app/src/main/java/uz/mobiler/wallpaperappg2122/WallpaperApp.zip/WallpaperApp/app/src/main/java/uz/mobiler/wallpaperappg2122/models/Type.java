package uz.mobiler.wallpaperappg2122.models;

public class Type{
    public String slug;
    public String pretty_slug;
}
