package uz.mobiler.wallpaperappg2122.models.models2;

public class Exif{
    public Object make;
    public Object model;
    public String name;
    public Object exposure_time;
    public Object aperture;
    public Object focal_length;
    public Object iso;
}
