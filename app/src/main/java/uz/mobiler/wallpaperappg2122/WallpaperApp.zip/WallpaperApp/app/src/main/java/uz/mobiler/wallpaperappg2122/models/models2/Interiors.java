package uz.mobiler.wallpaperappg2122.models.models2;

import java.util.Date;

public class Interiors{
    public String status;
    public Date approved_on;
}
