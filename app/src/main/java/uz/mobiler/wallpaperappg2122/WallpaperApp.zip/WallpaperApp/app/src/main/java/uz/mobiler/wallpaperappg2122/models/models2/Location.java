package uz.mobiler.wallpaperappg2122.models.models2;

public class Location{
    public Object title;
    public Object name;
    public Object city;
    public Object country;
    public Position position;
}
