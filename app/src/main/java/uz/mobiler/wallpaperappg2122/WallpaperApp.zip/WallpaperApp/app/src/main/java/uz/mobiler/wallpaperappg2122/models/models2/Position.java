package uz.mobiler.wallpaperappg2122.models.models2;

public class Position{
    public Object latitude;
    public Object longitude;
}
