package uz.mobiler.wallpaperappg2122.models.models2;

public class ProfileImage{
    public String small;
    public String medium;
    public String large;
}
