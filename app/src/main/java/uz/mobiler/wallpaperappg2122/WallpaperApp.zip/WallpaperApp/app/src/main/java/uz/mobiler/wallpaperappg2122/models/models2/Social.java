package uz.mobiler.wallpaperappg2122.models.models2;

public class Social{
    public String instagram_username;
    public String portfolio_url;
    public Object twitter_username;
    public Object paypal_email;
}
