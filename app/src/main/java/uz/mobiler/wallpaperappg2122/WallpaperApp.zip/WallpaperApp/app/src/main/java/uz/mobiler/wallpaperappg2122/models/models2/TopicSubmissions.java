package uz.mobiler.wallpaperappg2122.models.models2;

public class TopicSubmissions{
    public Interiors interiors;
    public BusinessWork businessWork;
}
